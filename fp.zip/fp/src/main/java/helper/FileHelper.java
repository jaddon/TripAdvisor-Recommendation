package helper;

import java.util.ArrayList;
import java.util.List;

public class FileHelper {

	public static List<String> Candidates(List<String> ls, List<Double> ld){
		// pick the candidates with the same highest value
		double min = ld.get(0);
		int j = 0;
		for(int i=1;i<ld.size();i++) {
			if(ld.get(i)==min) {
				j++;
			}
			else break;
		}
		System.out.println(j);
		List<String> newList = new ArrayList<>();
		for(int i=0;i<=j;i++) {
			newList.add(ls.get(i));
		}
		return newList;
	}

	public static void ReorderWithValue(List<String> ls, List<Double> ld, double value) {
		// substract all the double values in the list with "value"
		for(int i=0;i<ld.size();i++) {
			double sub = Math.abs(ld.get(i)-value);
			ld.set(i, sub);
		}
		// reorder the double list so that smaller value come first
		for(int i=0;i<ld.size();i++) {
			for(int j=0;j<ld.size()-i-1;j++) {
				if(ld.get(j)>ld.get(j+1)) {
					double temp = ld.get(j);
					String s = ls.get(j);
					ld.set(j, ld.get(j+1));
					ls.set(j, ls.get(j+1));
					ld.set(j+1, temp);
					ls.set(j+1, s);
				}
			}
		}
	}


}
