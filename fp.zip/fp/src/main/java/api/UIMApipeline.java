package api;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngine;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReader;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.collection.CollectionReader;
import org.apache.uima.fit.pipeline.SimplePipeline;

import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordLemmatizer;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordPosTagger;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordSegmenter;
import uima.Comments_reader;
import uima.Comments_split;
import uima.VectorWritter;

public class UIMApipeline {

	public static void main(String[] args) throws UIMAException, IOException {

		String trainPath = "src/main/resources/train/"; // train files for the first selection (with svm)
		String trainPath2 = "src/main/resources/train2/"; // train files for the second selection (only with tfidf)
		String testPath = "src/main/resources/test/"; // test files


		String featurePath = "src/main/resources/feature_word/feature.dat"; // predefined feature for the first selection
		String featurePath2 = "src/main/resources/feature_word/feature2.dat"; // from user entered feature for the second selection

		String svmTrain = "src/main/resources/SvmTrain.dat"; // svm train vector file
		String svmTest = "src/main/resources/SvmTest.dat"; // svm test vector file
		String train2 = "src/main/resources/train2.dat"; // tfidf file for the second selection


		CollectionReader readerTrain = createReader(Comments_reader.class,Comments_reader.FILE_ADDRESS, trainPath);

		AnalysisEngine seg = createEngine(StanfordSegmenter.class);
		AnalysisEngine c = createEngine(Comments_split.class);
		AnalysisEngine pos = createEngine(StanfordPosTagger.class);
		AnalysisEngine lemma = createEngine(StanfordLemmatizer.class);
		AnalysisEngine writerTrain = createEngine(VectorWritter.class,VectorWritter.OUTPUT_FILE_ADDRESS, svmTrain, VectorWritter.FEATURE_FILE_ADDRESS, featurePath);

		//generate the svm train vector file with the predefined feature
		SimplePipeline.runPipeline(readerTrain,seg,pos,c,lemma, writerTrain);

		CollectionReader readerTest = createReader(Comments_reader.class,Comments_reader.FILE_ADDRESS,testPath);
		AnalysisEngine writerTest = createEngine(VectorWritter.class,VectorWritter.OUTPUT_FILE_ADDRESS, svmTest, VectorWritter.FEATURE_FILE_ADDRESS, featurePath);

		//generate the svm test vector file with the predefined feature
		SimplePipeline.runPipeline(readerTest,seg,pos,c,lemma, writerTest);

		List<String> candidates = SvmPipeline.runSvm(args);// get the candidates (with the same overall rating and the overall rating is closest to the predicted value for test file)
		if(candidates.size()==1) {
            // if only one candidate then choose it
			System.out.println("Only one candidate, thus we choose the file: "+candidates.get(0));
			return;
		}
		// else choose the candidate with from user entered features
		else {
		   	File file = new File(trainPath);
	        String[] filelist = file.list();
	        for(String s1: filelist) {
	        	for(String s2: candidates) { // copy the candidate files to the new train folder
	        		if(s1.equals(s2)) {
	        			try {
	        				File fileSource = new File(trainPath+s1);
	        				File fileDest = new File(trainPath2+s1);
	        				Files.copy(fileSource.toPath(), fileDest.toPath());
	        			}
	        			catch(Exception e) {
	        			}
	        		}
	        	}
	        }
	        // let user enter some feature words
	        System.out.println("Please enter your feature word(s) separated with space");
	        Scanner sc = new Scanner(System.in);
	        String s = sc.nextLine();
	        try {
	        	// store the feature words to another feature file
	        	BufferedWriter bw = new BufferedWriter(
	                    new OutputStreamWriter(new FileOutputStream(featurePath2)));
	        	bw.write(s);
	        	bw.close();
	        }
	        catch(Exception e) {
	        }

	        CollectionReader readerTrain2 = createReader(Comments_reader.class,Comments_reader.FILE_ADDRESS,trainPath2);
	        AnalysisEngine writerTrain2 = createEngine(VectorWritter.class,VectorWritter.OUTPUT_FILE_ADDRESS, train2, VectorWritter.FEATURE_FILE_ADDRESS, featurePath2);
	        // use the selected train files and new feature file to get tfidf value for candidates
	        SimplePipeline.runPipeline(readerTrain2,seg,pos,c,lemma, writerTrain2);

	        File scoreFile = new File(train2); // list
	        File trainFile2 = new File(trainPath2);
	        String[] trainlist = trainFile2.list(); // list the selected candidates
	        List<Double> scores = new ArrayList<>(); // list the tfidf score of the selected candidates
            for (String st : FileUtils.readLines(scoreFile)) {
                if (st.isEmpty()) {
                    continue;
                }
                scores.add(Double.parseDouble(st.split("\t")[2]));
            }
            // reorder the lists so the candidate with higher score come first
            for (int i = 0;i<scores.size();i++) {
            	for(int j=0;j<scores.size()-i-1;j++) {
            		if(scores.get(j)<scores.get(j+1)) {
            			String temps = trainlist[j];
            			double tempd = scores.get(j);
            			trainlist[j] = trainlist[j+1];
            			scores.set(j, scores.get(j+1));
            			trainlist[j+1] = temps;
            			scores.set(j+1, tempd);
            		}
            	}
            }
            // choose the candidate with highest score (here we select the first one if more than one files have the same highest score)
            System.out.println("We choose file: "+trainlist[0]+", because it has the highest score for the given feature words");

		}
	}
}
