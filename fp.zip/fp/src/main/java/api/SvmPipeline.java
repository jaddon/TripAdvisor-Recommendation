package api;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;
import org.dkpro.tc.ml.libsvm.api.LibsvmPredict;
import org.dkpro.tc.ml.libsvm.api.LibsvmTrainModel;

import helper.FileHelper;

public class SvmPipeline {

	public static List<String> runSvm(String[] args) throws IOException {

		LibsvmTrainModel trainModel = new LibsvmTrainModel();
        // we use the default parameters for svm train in svr mode(regression)
		String[] argv = {"-s","4","-t","2","-d","3","-g","0","-r","0","-n","0.5","-m","100","-c","1","-e","1e-3","-p","0.1","-h","1","-b","0","src/main/resources/SvmTrain.dat"};
		// SvmTrain.dat offers the data for train
		try {
			trainModel.run(argv);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// we use the default parameters for svm predict
		LibsvmPredict predict =  new LibsvmPredict();
		String[] arg = {"-b","0","src/main/resources/SvmTest.dat","SvmTrain.dat.model","src/main/resources/SvmOutput.dat"};
		// SvmTrain.dat.model stores the trained model, SvmOutput.dat stores the predicted labels, SvmTest.dat offer the data for predict
		try {
			predict.main(arg);
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
        	BufferedWriter bw = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream("src/main/resources/OutputCompare.dat"))); // write the predicted with true labels in one file for comparison
        	File output = new File("src/main/resources/SvmOutput.dat");
        	File test = new File("src/main/resources/SvmTest.dat");

        	List<Double> outputs = new ArrayList<>();
            for (String s : FileUtils.readLines(output)) {
                if (s.isEmpty()) {
                    continue;
                }
                outputs.add(Double.parseDouble(s)); // add all the predicted labels
            }
            List<Double> tests = new ArrayList<>();
            for (String s : FileUtils.readLines(test)) {
                if (s.isEmpty()) {
                    continue;
                }
                tests.add(Double.parseDouble(s.split("\t")[0]));
            }
            for (int i=0;i<outputs.size();i++) {
            	bw.write(String.valueOf(outputs.get(i))); // write the predicted labels
            	bw.write("("+String.valueOf(tests.get(i))+")"); // write the true labels in "()"
            	bw.write("\n");
            }
            bw.close();

            File train = new File("src/main/resources/SvmTrain.dat");
            List<Double> trainRating = new ArrayList<>();
            for (String s : FileUtils.readLines(train)){
                if (s.isEmpty()) {
                    continue;
                }
                trainRating.add(Double.parseDouble(s.split("\t")[0]));
            }
    		File trainName = new File("src/main/resources/train/");
    		String[] filelistTrain = trainName.list();
    		HashMap<String, Double> trainRatingMap = new HashMap<>();
    		int i = 0;
    		for(String s : filelistTrain) {
    		    trainRatingMap.put(s, trainRating.get(i)); // add all train file names with their labels
    		    i++;
    		}

    		HashMap<String, Double> testRatingMap = new HashMap<>();
    		File testName = new File("src/main/resources/test/");
    		String[] filelistTest = testName.list();
    		i = 0;
    		for(String s : filelistTest) {
    		    testRatingMap.put(s, outputs.get(i)); // add all test file names with their labels
    		    i++;
    		}

    		// let user enter a location name
    		System.out.println("Please enter a location (lowercase)");
 	        Scanner sc = new Scanner(System.in);
 	        String location = sc.nextLine();
 	       boolean locationOK = false;
 	       for(String loc: trainRatingMap.keySet()) {
 	    	  if(loc.toLowerCase().contains(location)) {
 	    		 locationOK = true;
 	    		 break;
 	    	  }
 	       }
 	        while(!locationOK){
 	        	for(String loc: trainRatingMap.keySet()) {
 	 	        	if(loc.toLowerCase().contains(location)) {
 	 	        		locationOK = true;
 	 	        		break;
 	 	        	}
 	 	        }
 	        	if(!locationOK) {
 	        		System.out.println("The location you entered is not included, please enter a new location (lowercase)");
 	 	        	sc = new Scanner(System.in);
 	 	 	        location = sc.nextLine();
 	        	}
 	        }


    	    List<String> ls = new ArrayList<>();
    	    List<Double> ld = new ArrayList<>();
    	    for(Map.Entry<String, Double> entry: trainRatingMap.entrySet()) {
    	    	if(entry.getKey().toLowerCase().contains(location)) { // choose only the hotels with the same location name like the test file
    	    		ls.add(entry.getKey()); // store the hotel name
    	    		ld.add(entry.getValue()); // store the hotel overall rating(label)
    	    	}
    	    }
    	    FileHelper.ReorderWithValue(ls, ld, outputs.get(0)); // reorder so that hotel with rating close to the predicted value of test file will come first
    	    List<String> newList = FileHelper.Candidates(ls, ld); // pick the candidates with the same highest value
    	    return newList;

        }
    	catch (IOException e)
        {
           e.printStackTrace();
           return null;
         }

	}

}
